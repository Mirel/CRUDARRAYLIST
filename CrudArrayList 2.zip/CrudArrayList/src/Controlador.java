import java.util.ArrayList;
import java.util.Scanner;
/**
 * Realizaremos la mismas funcionalidades que en la primera práctica.
 * En este caso modificaremos la práctica para que:
 * Se use POO, es necesario realizar las clases y llamar a las funcionalidades mediante métodos de los objetos creados.
 * Se utilizarán ArrayList para realizar el almacenamiento de los datos, concretamente ArrayList de objetos, por ejemplo si el tema fuese cine; ArrayList<Pelicula> misPelis;
 * No hay limitación de 20 películas.
 */

/**
 * Creo la clase controlador con los métodos de logica y gestión de almazenamiento de los datos de la colección de libros.
 * Abro el Scanner en static para toda la clase que contiene métodos que pide datos al usuario.
 */
public class Controlador {
    static Scanner sc = new Scanner(System.in);
    static GestionLibros gestionarLibros = new GestionLibros(new ArrayList<>());

    //el main donde llamo al método logica del menu de gestión de libros. Y también cierro el Scanner.
    public static void main(String[] args) {

        logica();
        sc.close();


    }

    /**
     * método con estructura de un bucle "do" del Menu para que  aparecera todo el tiempo hata que pida la entrada 0.
     * controlo con un if else si la entrada es correcta y si no es, devuelve el mensaje de error.
     */
    public static int menu() {
        int opcion;
        boolean entradaCorrecta;

        do {
            System.out.println("    MENU PRINCIPAL: ");
            System.out.println("    1. Añadir libro ");
            System.out.println("    2. Buscar libro por título ");
            System.out.println("    3. Buscar libro por autor ");
            System.out.println("    4. Buscar libro por tipología ");
            System.out.println("    5. Modificar libro ");
            System.out.println("    6. Eliminar libro ");
            System.out.println("    0. Salir.");
            System.out.println("Introduce tu opcion: ");
            opcion = sc.nextInt();
            if (opcion < 0 || opcion > 6) {
                System.out.println("Error. Opcion incorrecta. Prueba de nuevo.");
                entradaCorrecta = false;
            } else
                entradaCorrecta = true;
        } while (!entradaCorrecta);

        return opcion;
    }

    /**
     * Método con la logica del menu , donde direcciono con switch a cada método de acuerdo con la entrada del menu.
     */
    public static void logica() {
        int opcion;

        System.out.println("BIENVENIDO AL GESTOR DE COLECCIÓN DE LIBROS");

        do {
            opcion = menu();

            switch (opcion) {
                case 1: {
                    anadirLibro();
                    break;
                }
                case 2: {
                    buscarporTitulo();
                    break;
                }
                case 3: {
                    buscarporAutor();
                    break;
                }
                case 4: {
                    buscarporTipo();
                    break;
                }
                case 5: {
                    modificarLibro();
                    break;
                }
                case 6: {
                    eliminarLibro();
                    break;
                }
                case 0: {
                    System.out.println("Fin del programa.");
                    break;
                }
            }
        } while (opcion != 0);
    }

    /**
     * método que gestiona la entrada de los datos pedidos en el menu elegido por el usuario.
     * llama al método agregarLibro de la clase GestiónLibros que añade los datos de entrada al ArrayList
     */
    public static void anadirLibro() {
        String titulo = pedirTitulo(true);
        String autor = pedirAutor(true);
        String tipo = pedirTipo(true);
        ColeccionLibros libro1 = new ColeccionLibros(titulo, autor, tipo);
        gestionarLibros.agregarLibro(libro1);
        System.out.println("Se ha almacenado. ");
    }

    /**
     * llamo al método que recoge los datos y cuando lo encuentra, llamo al método imprimirLibro
     * para que muestre todos los datos correspondientes al títudo elegido
     */
    public static void buscarporTitulo() {
        String titulo = pedirTitulo(true);
        ArrayList<ColeccionLibros> libros = gestionarLibros.buscarLibroPorTitulo(titulo);
        imprimirLibros(libros);

    }

    /**
     * llamo al método que recoge los datos y cuando lo encuentra, llamo al método imprimirLibro
     * para que muestre todos los datos correspondientes al Autor elegido
     */
    public static void buscarporAutor() {
        String autor = pedirAutor(true);
        ArrayList<ColeccionLibros> libros = gestionarLibros.buscarLibroporautor(autor);
        imprimirLibros(libros);
    }

    /**
     * llamo al método que recoge los datos y cuando lo encuentra, llamo al metodo imprimirLibro
     * para que muestre todos los datos correspondientes al tipo elegido
     */
    public static void buscarporTipo() {
        String tipo = pedirTipo(true);
        ArrayList<ColeccionLibros> libros = gestionarLibros.buscarLibroportipo(tipo);
        imprimirLibros(libros);
    }

    /**
     * método que pide el dato buscado por  el usuario.
     * @param validar pasamos por parámetro la booleana validar que nos indica si la entrada es correcta.
     * @return retorna la tipologia añadida
     */
    private static String pedirTitulo(boolean validar) {
        boolean entradaCorrecta = false;
        String titulo = null;
        do {
            System.out.println("Introduce el titulo: ");
            titulo = sc.next();
            sc.nextLine();
            if (titulo.length() > 100) {
                System.out.println("El titulo no puede ser mayor que 100 caracteres");
            } else {
                entradaCorrecta = true;

            }

        } while (!entradaCorrecta);
        return titulo;

    }

    /**
     * método que pide el dato buscado por  el usuario.
     * @param validar pasamos por parámetro la booleana validar que nos indica si la entrada es correcta.
     * @return retorna la tipologia añadida
     */
    private static String pedirAutor(boolean validar) {
        boolean entradaCorrecta = false;
        String autor = null;

        do {
            System.out.println("Introduce el autor: ");
            autor = sc.next();
            sc.nextLine();
            if (autor.length() > 100 && validar) {
                System.out.println("El nombre del autor no puede ser mayor que 100 caracteres");
            } else {
                entradaCorrecta = true;

            }

        } while (!entradaCorrecta);
        return autor;

    }

    /**
     * método que pide el dato buscado por  el usuario.
     * @param validar pasamos por parámetro la booleana validar que nos indica si la entrada es correcta.
     * @return retorna la tipologia añadida
     */
    private static String pedirTipo(boolean validar) {
        boolean entradaCorrecta = false;
        String tipo = null;

        do {
            System.out.println("Introduce la tipologia");
            tipo = sc.next();
            sc.nextLine();
            if (tipo.length() > 20) {
                System.out.println("La tipologia no puede tener mas de 20 caracteres ");
            } else {
                entradaCorrecta = true;

            }

        } while (!entradaCorrecta);
        return tipo;

    }

    /**
     * Método que gestiona la opción de modicficar libro. Ao elegir el el titudo del libro que desea modificar se borran todos los datos correspondientes
     * y llamo al metodo añadirLibro para solicitar los datos del nuevo libro.
     * Si todo es correcto le devolverá el mensaje de libro modificado.
     */
    public static void modificarLibro() {
        String titulo = pedirTitulo(true);
        ArrayList<ColeccionLibros> libros = gestionarLibros.buscarLibroPorTitulo(titulo);
        libros.remove(new String(titulo));
        System.out.println("Ahora introduce los datos del nuevo libro");
        anadirLibro();
        System.out.println("Libro Modificado!");


    }

    /**
     * Método que gestiona la opción de eliminar libro. Ao elegir el el titudo del libro que desea modificar se borran todos los datos correspondientes
     */
    public static void eliminarLibro() {
        String titulo = pedirTitulo(true);
        ArrayList<ColeccionLibros> libros = gestionarLibros.buscarLibroPorTitulo(titulo);
        libros.remove(new String(titulo));
        System.out.println("Se ha eliminado correctamente.");

    }

    /**
     * Método que recoge todo el ArrayList con los datos de la clase ColeccionLibros.
     * @param libros devuelve todos los datos del libro con un toString.
     */
    public static void imprimirLibros(ArrayList<ColeccionLibros> libros) {
        System.out.println("Resultado de la busqueda: ");
        for (ColeccionLibros n : libros) {
            System.out.println(n.toString());
        }
        if (libros.isEmpty()) {
            System.out.println("No se ha encontrado resultados ");
        }
        System.out.println("");

    }
}