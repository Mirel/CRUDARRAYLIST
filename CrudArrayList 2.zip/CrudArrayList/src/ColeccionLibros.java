public class ColeccionLibros {
    /**
     * declaro variables de los datos de entrada y salida y añado el constructor y sus getters y setters y to String correspondientes.
     */
    private String titulo;
    private String autor;
    private String tipo;

    public ColeccionLibros(String titulo, String autor, String tipo) {
        this.titulo = titulo;
        this.autor = autor;
        this.tipo = tipo;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "ColecciónLibros{" +
                "titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}