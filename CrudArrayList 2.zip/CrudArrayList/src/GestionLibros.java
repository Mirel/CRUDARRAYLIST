import java.util.ArrayList;

public class GestionLibros {
    /**
     * Declaro el ArrayList con sus getters y setter y to string correspondientes
     */
    private ArrayList<ColeccionLibros> libros = null;

    public GestionLibros(ArrayList<ColeccionLibros> libros) {
        this.libros = libros;
    }

    public ArrayList<ColeccionLibros> getLibros() {
        return libros;
    }

    public void setLibros(ArrayList<ColeccionLibros> libros) {
        this.libros = libros;
    }

    @Override
    public String toString() {
        return "GestionLibros{" +
                "libros=" + libros +
                '}';
    }

    //Metodo que añade los datos añadidos al ArrayList
    public void agregarLibro(ColeccionLibros libro) {
        libros.add(libro);

    }

    //Metodo que recoge la lista con un bucle for each hasta buscar el título
    public ArrayList<ColeccionLibros> buscarLibroPorTitulo(String titulo) {

        ArrayList<ColeccionLibros> resultados = new ArrayList<ColeccionLibros>();
        for (ColeccionLibros n : libros) {
            if (n.getTitulo().equals(titulo)) {
                resultados.add(n);
            }

        }
        return resultados;

    }

    //Metodo que recoge la lista con un bucle for each hasta buscar el autor
    public ArrayList<ColeccionLibros> buscarLibroporautor(String autor) {
        ArrayList<ColeccionLibros> resultados = new ArrayList<ColeccionLibros>();
        for (ColeccionLibros n : libros) {
            if (n.getAutor().equals(autor)) {
                resultados.add(n);
            }

        }
        return resultados;
    }

    //Metodo que recoge la lista con un bucle for each hasta buscar la tipologia
    public ArrayList<ColeccionLibros> buscarLibroportipo(String tipo) {
        ArrayList<ColeccionLibros> resultados = new ArrayList<ColeccionLibros>();
        for (ColeccionLibros n : libros) {
            if (n.getTipo().equals(tipo)) {
                resultados.add(n);
            }

        }
        return resultados;

    }

}
